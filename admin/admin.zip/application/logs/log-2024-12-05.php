<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-05 15:54:29 --> Config Class Initialized
INFO - 2024-12-05 15:54:29 --> Hooks Class Initialized
DEBUG - 2024-12-05 15:54:29 --> UTF-8 Support Enabled
INFO - 2024-12-05 15:54:29 --> Utf8 Class Initialized
INFO - 2024-12-05 15:54:29 --> URI Class Initialized
DEBUG - 2024-12-05 15:54:29 --> No URI present. Default controller set.
INFO - 2024-12-05 15:54:29 --> Router Class Initialized
INFO - 2024-12-05 15:54:29 --> Output Class Initialized
INFO - 2024-12-05 15:54:29 --> Security Class Initialized
DEBUG - 2024-12-05 15:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 15:54:29 --> Input Class Initialized
INFO - 2024-12-05 15:54:29 --> Language Class Initialized
INFO - 2024-12-05 15:54:29 --> Loader Class Initialized
INFO - 2024-12-05 15:54:29 --> Helper loaded: url_helper
INFO - 2024-12-05 15:54:29 --> Helper loaded: form_helper
INFO - 2024-12-05 15:54:29 --> Database Driver Class Initialized
DEBUG - 2024-12-05 15:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-05 15:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-05 15:54:29 --> Form Validation Class Initialized
INFO - 2024-12-05 15:54:29 --> Controller Class Initialized
INFO - 2024-12-05 15:54:29 --> File loaded: C:\xampp\htdocs\sewamotormu\admin\application\views\dashboard.php
INFO - 2024-12-05 15:54:29 --> Final output sent to browser
DEBUG - 2024-12-05 15:54:29 --> Total execution time: 0.1612
